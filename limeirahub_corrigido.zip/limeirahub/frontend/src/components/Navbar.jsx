function Navbar() {
  return <nav>Navbar</nav>;
}

export default Navbar;