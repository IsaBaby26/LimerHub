function CardAnuncio() {
  return <div>Card de Anúncio</div>;
}

export default CardAnuncio;