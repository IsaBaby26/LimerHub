import React from "react"
import Navbar from "./components/Navbar"

function App() {
  return (
    <div>
      <Navbar />
      <h1>Bem-vindo ao LimeiraHUB!</h1>
    </div>
  )
}

export default App;